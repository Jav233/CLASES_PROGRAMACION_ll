num1 = int(input("Introduce el primer numero: "))
num2 = int(input("Introduce el segundo numero: "))

suma = num1 + num2
resta= num1 - num2
multiplicacion = num1 * num2
division = num1 / num2
potencia = num1 ** num2
division_entera = num1//num2
modulo = num1 % num2

print("La suma es: ", suma)
print("La resta es: ", resta)
print("La multiplicacion es: ", multiplicacion)
print("La division es: ", division)
print("La potencia es: ", potencia)
print("La division entera es: ", division_entera)
print("El modulo es: ", modulo)
