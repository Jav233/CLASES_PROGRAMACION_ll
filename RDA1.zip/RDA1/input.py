nombre = input("Cual es tu nombre?: ")
edad = int (input("Cuantos años tienes?: "))
altura = float(input("Cuanto mides?: "))

print("Hola", nombre, "tienes", edad, "años")
print("Mides", altura, "metros")
