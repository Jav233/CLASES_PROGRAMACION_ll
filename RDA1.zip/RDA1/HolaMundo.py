#Seleccionar todo control d y alt click izquierdo
# control /
# p=5 
# q = 9
# if p > 3 and q < 10:
#     print("Hola Mundo")
# else:
#     print("Adios Mundo")

efectivo = 'si'
transferencia = 'no' # no se puede hacer doble pago
tc = 'no' # no se puede hacer doble pago

if efectivo == 'si' or transferencia == 'si' or tc == 'si':
    print("Puedes comprar el coche")
else:
    print("No puedes comprar el coche")