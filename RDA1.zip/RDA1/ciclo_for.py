#Por posicion
# for i in range(5):
#     print(i)

# for i in range(1, 10):
#     print(i)

# for i in range(1, 10+1, 2):
#     print(i)

# for i in range(0, 5+1):
#     print("Tabla del ", i)
#     for j in range(0, 10+1):
#         print(i, "x", j, "=", i*j)  # Aquí se imprim

# for i in [0,10,2]:
#     print("Emeneses", i)

# for i in [2,4,8]:
#     print("El valor de ", i, "Y su cuadrado es", i**2)

# pos = 0
# for i in ['Edison', 20, 'Ecuador', True]:
#     pos+=1
#     print(f"El valor de i en la posicion {pos} es: ", i)  # Aquí se imprime el valor de i en cada iteración
    

# for i in [1,2,3,4,5]:
#     print("Tabla del ", i)
#     for j in [1,2,3,4,5]:
#         print(i, "x", j, "=", i*j)  # Aquí se imprim

# resto = 5%2
# print("El resto de 5 entre 2 es: ", resto)  # Aquí se imprime el resto de la división de 5 entr
# if resto == 0:
#     print("El resto es par")  # Aquí se imprime el mensaje si el
# else:
#     print("El numero es impar")
    
# for i in [1,2,3,4,5,6,7,8,9,10]:
#     if i % 2 == 0:
#         print(i, "es par")  
#     else:
#         print(i, "es impar")  
# print("--------------------------")
# for i in [1,2,3,4,5,6,7,8,9,10]:
#     if i % 2 == 0:
#         print(i, "es par")
# print("--------------------------")
    
                
# for i in [1,2,3,4,5,6,7,8,9,10]:
#     if i % 2 != 0:
#         print(i, "es impar")
# print("--------------------------")  # Aquí se imprime el mensaje si el numero es impar

# for i in range (1, 4):
#     print("Hola Edison como estas", i)  # Aquí se imprime el mensaje "Hola" 3 veces  
    
# for j in range(0,5+1):
#     print("Tabla del ", j)
#     for k in range(0,5+1):
#         for i in range(0,5+1):
#             print(j, "x", k,'x',i, "=", j*k*i)  # Aquí se imprime

# for t in [1,2,3]:
#     print("Emeneses ", end='')

# for t in [1,2,3]:
#     print("Emeneses ", t)

# print("Operaciones entre elementos de una lista")
# for r in [10,200,30]:
#     print("El valor de r al cuadrado es: ", r**2)  # Aquí se imprime el
# print("///////////////////////////////////////////////")
# for r in [10,200,30]:
#     print("----------------------------")
#     print("El valor de r es: ", r)
#     print("----------------------------")
#     for k in [40,50,60]:
#         print(f"El valor r {r} x k {k}: {r*k}")
#         #print("-----------------------------------")
        
# resto = 5%2
# if resto == 0:print("El numero es par")
# else: print("El numero es impar")  # Aquí se imprime el mensaje si

for i in [0,1,2,3,4,5,6,7,8,9,10]:
    if i % 2 == 0:print("El numero es par", i)
# Aquí se imprime el mensaje si
print("-----------------------------------------")
for i in [0,1,2,3,4,5,6,7,8,9,10]:
    if i % 2 != 0:print("El numero es impar", i)
# Aquí se imprime el mensaje si