a=5
b=2.5
c="Hola mundo"
d='Mundo'
e= True

print(a, 'Es de tipo', type(a))
print(b, 'Es de tipo', type(b))
print(c, 'Es de tipo', type(c))
print(d, 'Es de tipo', type(d))
print(e, 'Es de tipo', type(e))